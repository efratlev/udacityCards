# UdacityCards

Install and run steps:

Install and run on android:
npm install -g react-native-cli
cd react-native-quick-sample
npm install
react-native run-android

Install and run on ios:
npm install -g react-native-cli
cd react-native-quick-sample
npm install
react-native run-ios